# todolistphp
Php crud list
Functions: 
Add
Delete
Update
Mark Completed (still need to add)
